//-----------------------------------------------------------------------------
// Andreive Giovanini Silva 
// 1506403 
// 12B
// 05/09/2016
// QueueEmptyException.java
// QueueEmptyException that extends the class RuntimeException 
//-----------------------------------------------------------------------------

public class QueueEmptyException extends RuntimeException{
   public QueueEmptyException(String s){
      super(s);
   }
}
