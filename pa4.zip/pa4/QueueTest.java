//-----------------------------------------------------------------------------
// Andreive Giovanini Silva 
// 1506403 
// 12B
// 05/09/2016
// QueueTest.java
// Class used to test Queue ADT methods before implementing the simulation
//-----------------------------------------------------------------------------

class QueueTest{

   public static void main(String[] args){

      Job a, b, c, d, e;
      Queue Q = new Queue();
      Queue C;

      a = new Job(2, 2);
      b = new Job(3, 4);
      c = new Job(5, 6);
      d = new Job(7, 8);
      e = new Job(8, 9);

      System.out.println("Testing isEmpty() function");
      System.out.println(Q.isEmpty());
      System.out.println();

      System.out.println("Testing enqueue() function and isEmpty() again");
      Q.enqueue(a);
      System.out.println(Q.isEmpty());
      System.out.println();

      System.out.println("Testing enqueue(), length() and toString() functions");
      Q.enqueue(b);
      Q.enqueue(c);
      System.out.println(Q.length());
      System.out.println(Q);
      System.out.println();

      System.out.println("Testing dequeue() function");
      Q.dequeue();
      System.out.println(Q.length());
      System.out.println(Q);
      System.out.println();

      System.out.println("Testing peek() function");
      System.out.println(Q.peek());
      System.out.println(Q.length());
      System.out.println(Q);
      System.out.println();

      System.out.println("Adding some more jobs");
      Q.enqueue(d);
      Q.enqueue(e);
      System.out.println(Q.length());
      System.out.println(Q);
      System.out.println();

      System.out.println("Testing copyQueue(). After copy, dequeueAll() is used in original Queue");
      C = (Queue) Q.copyQueue();
      Q.dequeueAll();
      System.out.println("Original Queue");
      System.out.println(Q.length());
      System.out.println(Q.isEmpty());
      System.out.println(Q);
      System.out.println("Copied Queue");
      System.out.println(C.length());
      System.out.println(C.isEmpty());
      System.out.println(C);
      System.out.println();

   }

}

